return function(page, offset, screen_width, screen_height)
    local percent1 = math.abs(offset/page.width)

    page.alpha = 1 - percent1
	
	page:translate(0, 0, -math.abs(offset/2))

	    page.layer.x = page.layer.x + offset

    local percent = offset/page.width

    if math.abs(percent) >= 0.5 then
        page.alpha = 0
    end

    page:rotate(-math.pi*percent, 0, 1, 0)

end