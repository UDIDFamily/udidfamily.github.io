return function(page, offset, width, height)
    local percent = offset/width
    if math.abs(percent) >= 0.5 then page.alpha = 0 end
    page:translate(offset, 0, 0)
    local i = 0
    while true do
        i = i + 1
        local icon = page[i]
        if icon == nil then break end
        icon:rotate(percent*math.pi, 0, -1, 0)
    end
end