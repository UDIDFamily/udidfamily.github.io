--[[ ******************************************************************
Gravity by KOP
******************************************************************* ]]
local animations = {}
for i=1,24,1 do
        animations[i] = 0
end
local a2 = {}
for i=1,48,1 do
        a2[i] = 0
end

local a3 = {}
for i=1,24,1 do
        a3[i] = 0
end
return function(pg, of, sw, sh)

        -- pg:translate(of,0,0)

    local pc, cx, cy, ops = math.abs(of/pg.width), pg.width/2, pg.height/2, of/pg.width
        -- target distance
        local tg = pg.width
        local fnum=1;
        local fx=5*pc
        local de = 3*pc
        if de>1 then de=1 end
        if fx>1 then fx=1 end
    for i, ic in subviews(pg) do
if pc<=0.001 then for i=1,24,1 do
        animations[i] = math.random(-100, 100)
end
end
if pc<=0.01 then for i=1,48,1 do
        a2[i] = math.random(100, 200)
end
end
if pc<=0.001 then for i=1,24,1 do
        a3[i] = math.random(100, 100)
end
end
local ba=0
if ops<0 then ba=24 end
                -- get icon center
                local icx, icy = (ic.x+ic.width/2), (ic.y+ic.height/2)
                -- get icon offset from page center
                local ox, oy = cx-icx, cy-icy
                local ax, ay = math.abs(ox), math.abs(oy)
                -- get angle of icon position
                local ang = math.atan2(oy,ox)
local ang2 = math.atan(ay/ax)
                -- get hypotenuse
                local h = math.sqrt( ox^2+oy^2)
                -- get hypotenuse extension
                local oh = pc*tg+de*(1.44^(2*pc+1)-3.35*de^0.33)*h
                local g = pc-0.33333333
   if g<0 then g=0 end
                -- directions
                local dx, dy = 1,1
                if icx<cx then dx=-dx end
                if icy<cy then dy=-dy end
                if icy==cy then dy=0 end
                if ang>=math.pi then fnum=-1 end
                if ang<math.pi then fnum=1 end
                -- calc new x & y
                -- local nx = oh * math.cos(ang2) * dx
                local ny = 0
                ny = pc*.3*pg.height*(a2[i+ba]/133)
                ny=ny^1.5
                -- move!
                ic:translate(0, ny)
                
                
                -- if pc>0.6 then
                        -- ic.alpha = 1-pc^4
                -- end

    end
end

