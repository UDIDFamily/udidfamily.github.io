--Andaharoo
--12/06/14
--Helix

return function(page, offset, screen_width, screen_height)
    local percent = offset/page.width --%AcrossScreen
    local y = percent*(page.height+20)--YPos
    local A = page.width/2.7          --Amplitude
    local B = math.pi/(page.height/1.5) --Period
    local ps = B                      --Phase Shift
    local shift = -A                  --Shift
    local x = 0                       --InitXPos

    for i, icon in subviews(page) do
        if icon.x + icon.width/2 < page.width/2 then
            x = -A*math.cos(B*y + ps) - shift
        else
            x = A*math.cos(B*y + ps) + shift
        end
        page[i]:translate(offset + x, y, 0)
    end

end

--To Use
--Open iFile
--Navigate to /Library/Cylinder/
--Create a new directory or use an old one.
--Create a file named whatever. I used "Helix.lua" 
--Make sure it has ".lua" as the suffix
--Go to Cylinder in options, select the effect, and   --enjoy.