local icon_random = dofile("include/24984923748723472342536562342374.lua")

return function(page, offset, screen_width, screen_height)
      local magnitude = 0.8
    
    icon_random(page, offset/page.width, magnitude, function(icon, percent2)
        icon:rotate(math.pi*percent2, 0, 1, 0)
        if math.abs(percent2) >= 0.5 then
            icon.alpha = 0
        else
            icon.alpha = 1
        end
        --icon.alpha = 1 - math.abs(percent)
    end)
	
	
    page:translate(offset)

    local percent3 = math.abs(offset/page.width)
    for i, icon in subviews(page) do
        local m
        if icon.x + icon.width/2 > page.width/2 then
            m = 1
        else
            m = -1
        end
        icon:translate(m*2*percent3*page.width/2)
    end

	local percent = math.abs(offset/page.width)
    
    local centerX = page.width/2
    local centerY = page.height/2+7
    local radius = 0.60*page.width/2
    if radius > page.height then radius = 0.60*page.height/2 end
    
    local theta = (2*math.pi)/#page.subviews
    
    local endStage1P = 1/2
    local endStage2P = 1
    
    local stage1P = percent*(1/endStage1P)
    if (stage1P > 1) then stage1P = 1 end
    
    local stage2P = (percent-endStage1P)*(1/(endStage2P-endStage1P))
    if (stage2P > 1) then stage2P = 1
    elseif (stage2P < 0) then stage2P = 0 end
    
    for i, icon in subviews(page) do
        local iconAngle = theta*(i-1)+stage2P*(math.pi/2)
        
        local begX = icon.x+icon.width/2
        local begY = icon.y+icon.height/2
        
        local endX = centerX+radius*math.cos(iconAngle)
        local endY = centerY-radius*math.sin(iconAngle)
        
        icon:translate((endX-begX)*stage1P, (endY-begY)*stage1P, 0)
        icon:rotate(-stage1P*((math.pi/2) + iconAngle))
    end
end