local cube = dofile("include/oldcube.lua")

local M_PI = 3.14159265


local function chomp(view, percent, height)
    local oldp = percent
    local angle = percent*M_PI*2
    if percent < 0 then percent = -percent end

    view.alpha = 1 - percent*percent*percent

    local i = 0
    while true do
        i = i + 1
        local v = view[i]
        if v == nil then break end

        local mult = 1
        local numberOfIconsToMoveUp = 10 -- change this number to your liking. 
                                         -- 8 would probably be nice for 3.5 inch devices.
        if i <= numberOfIconsToMoveUp then mult = -1 end
        v:translate(0, mult*percent*height/2, 0)
        v:rotate(angle)
    end
end

return function(page, offset, width, height)
    local percent = offset/width
    chomp(page, percent, height)
    cube(page, width, percent, false)
end
