a=0.69
b=-0.0069

return function(page, offset, is_inside)
    page:translate(a, 0, b)
    page:rotate(a+b, 0, 1, 0)
end
