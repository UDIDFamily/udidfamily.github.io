--[[ ******************************************************************
Tornado by KOP
		
******************************************************************* ]]

return function(pg, of, sw, sh)

	pg:translate(of,0,0)

    local pc, cx, cy = math.abs(of/pg.width), pg.width/2, pg.height/2
	-- target distance
local midx =pg.width/2

	local midy =pg.height/2+7
	local tg = pg.width
	local fx = pc*5
	if fx>1 then fx=1 end
local side = -1

	-- if(of>0) then side=1 end
    for i, ic in subviews(pg) do
		-- get icon center
		local icx, icy = (ic.x+ic.width/2), (ic.y+ic.height/2)
		-- get icon offset from page center
		local ox, oy = math.abs(cx-icx), math.abs(cy-icy)
		-- get angle of icon position
		local ang = math.atan(oy/ox)
		-- get hypotenuse
		local h = math.sqrt( ox^2+oy^2)
local iconX = ic.x+ic.width/2
		local fall = (1-pc)*h
	  local iconY = ic.y+ic.height/2
		-- get hypotenuse extension
		local oh = fx*h+fx*tg
		-- directions
		local dx, dy = 1,1
		if icx<cx then dx=-dx end
		if icy<cy then dy=-dy end
		if icy==cy then dy=0 end
		local nx = 0
local ny = 0
		-- calc new x & y
		-- local nx = math.sqrt(h^2-oy^2)
		-- local ny = math.sqrt(h^2-ox^2)
		nx =midx+dx*fall*math.cos(pc*6*math.pi*ang)
		ny =2*midy-2.75*fall+math.sin(pc*4*math.pi*ang)
		local size=(3-fx)*(fall/h)
		if size>1 then size=1 end
		-- move!!
		ic:translate(fx*(nx-iconX),fx*(ny-iconY),0)
-- ic:scale(size*size)
-- ic:translate(-0.5*nx,-0.5*ny,0)
		
		-- if pc>0.6 then
			ic.alpha = 1-pc
		-- end

    end
end

