local cube = dofile("include/oldcube.lua")
local M_PI = 3.14159265
return function(page,offset,width,height)

     local percent = -(offset/width)
     local angle = percent*M_PI*2
    --if percent < 0 then percent = -percent end

    page.alpha = 1 - percent*percent*percent

     local i = 0
     while true do
     i = i + 1
     local v = page[i]
     if v == nil then break end
     
     v:translate((offset + percent*315),0,0)
     v:rotate(angle)
     --page:translate((offset + percent*100),0,0)
     cube(v,width,percent*0.6)

end
end
