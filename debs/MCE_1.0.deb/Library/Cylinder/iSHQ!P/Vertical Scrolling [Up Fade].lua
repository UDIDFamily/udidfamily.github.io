--[[ =_=_=
V v1.0
(c) by MrAwesome8

Barrels Vertical Scrolling

v1.0 2014-02-16: Initial Release (With Compatibility for Cylinder v0.13.2.15)
 
=_=_= ]]


return function(page, offset, screen_width, screen_height)
    local percent = offset/screen_width
	 local percent2 = math.abs(offset/screen_width)
    local x = (percent * screen_height) * -1
	page:translate(offset, x, 0)
	 page.alpha = 1 - percent2

end


