local M_PI = 3.14159265

local function scroll(view, percent, height, width)
    local oldp = percent

    local i = 0
    while true do
        i = i + 1
        local v = view[i]
        if v == nil then break end

        v:translate(percent*width,percent*height, 0)
    end
end
local function fade(page,percent)
        local p = percent
        if percent < 0 then p = -p end
        page.alpha = 1 - p
end
return function(page, offset, width, height)
    local percent = offset/width
    scroll(page, percent, height, width)
    fade(page,percent)
end