--[[ - @saman | 16 Feb 2014
Slice v1.0
]]
return function(page, offset, screen_width, screen_height)
local percent = offset/page.width
local y = percent*100
local ar = screen_width/screen_height
local f = y*2
if ar == 0.75 then f = y*2.5 end
page:translate(-f, y, f)
end