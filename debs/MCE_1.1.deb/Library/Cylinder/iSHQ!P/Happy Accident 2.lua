local function slide(view, percent,height,offset)
    local oldp = percent
    if percent < 0 then percent = -percent end

    local i = 0
    while true do
        i = i + 1
        local v = view[i]
        if v == nil then break end

        local mult = 1
	--is this if even necessary? lol
        if (i % #view.subviews/i < i) then mult = -i end
        v:translate(mult*offset/25, 0)
    end
end
local function fade(page,percent)
        local p = percent
        if percent < 0 then p = -p end
        page.alpha = 1 - p
end
return function(page, offset, width, height)
    local percent = offset/width
    slide(page, percent, height ,offset)
    fade(page,percent)
end