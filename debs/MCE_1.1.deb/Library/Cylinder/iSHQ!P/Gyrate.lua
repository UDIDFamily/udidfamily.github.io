return function(page, offset, screen_width, screen_height, icon)
    local percent = offset/page.width
	local dem=offset*page.height
	local icon=page
	icon:rotate(percent-dem+33,0,0,1)
end