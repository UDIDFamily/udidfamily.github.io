--[[ =_=_=

V v1.0

(c) by MrAwesome8



A Corkscrew like animation



v1.0 2014-02-16: Initial Release (With Compatibility for Cylinder v0.13.2.15)



=_=_= ]]



local cube = dofile("/include/old2cube.lua")



return function (page, offset, screen_width, screen_height)

    local percent = offset/screen_width

	local percent2 = math.abs(offset/screen_width)

    local x = (percent * screen_height) * -1



	page:translate(offset, x, 0)



   cube(page, percent, false)

	if percent < 0 then percent = -percent end

    --page.alpha = 1 - math.pow(percent, 3)

	 page.alpha = 1 - percent2



end