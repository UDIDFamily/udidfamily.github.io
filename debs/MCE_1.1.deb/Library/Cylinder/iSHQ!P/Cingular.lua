local function raise(view, percent, screen_height, screen_width,offset)
    local i = 0
    while true do
        i = i + 1
        local v = view[i]
        if v == nil then break end

        local mult=-i/8
        v:translate(offset,mult*offset, 0)
        view:translate(0,-offset/25)
    end
end
local function fade(page,percent)
        local p = percent
        page.alpha = 1 - math.abs(p)
end
return function(page, offset, screen_width, screen_height)
    local percent = offset/screen_width
    raise(page, percent, screen_height, screen_width,offset)
    fade(page, percent)
end
