--[[ =_=_=
V v1.0
(c) by MrAwesome8

All the icons separate

v1.0 2014-02-17: Initial Release (With Compatibility for Cylinder v0.13.2.15)

=_=_= ]]


local function distance(x1, y1, x2, y2)
    return math.sqrt(math.pow(x1 - x2, 2) + math.pow(y1 - y2, 2))
end

return function(page, offset, screen_width, screen_height)
    local percent = math.abs(offset/page.width)

    local center_x = page.width/2
    local center_y = page.height/2

    local i = 0
    while true do
        i = i + 1
		center_y = center_y + 33
		center_x = center_x + 33
        local icon = page[i]
        if not icon then break end

        local x = ((icon.x + icon.width) + center_x - (center_x/1.5))/(math.frexp(4))^2
        local y = ((icon.y + icon.height) + center_y - (center_y/1.5))/(math.frexp(4))^2

        local hypotenuse = ((percent*distance(x, y, center_x, center_y))^2)
        local angle = math.atan((center_x - x)/((center_y - y)))

		local dx = math.sqrt((hypotenuse*math.sin(angle))/2)
        local dy = math.sqrt((hypotenuse*math.cos(angle))/2)


		icon:translate(dx, dy, 0)

    end
end
