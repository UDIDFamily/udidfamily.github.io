return function(page, offset, swidth, sheight)
  local percent = offset/page.width
  page.layer.x = page.layer.x + offset
  if percent > 0 then
    mult = 4
  else
    mult = 1
  end
  for i, icon in subviews(page) do
    local distx = icon.x+(icon.width/2)-(page.width/2)
    local disty = icon.y+(icon.height/2)-(page.height/2)
    icon:translate(mult*distx*percent, mult*disty*percent, 0)
  end
  if percent < 0 then
    page.alpha = 1 - math.abs(percent)/0.85
  end
end