-- A Lua script which makes the apps calmly spin and fade.
-- Put file in Library/Cylinder
return function(page, offset, screen_width, screen_height)
    local percent = offset/page.width
    page:translate(offset, 0, 0)
    i = 0
    while true do
        i = i + 1
        local v = page[i]
        if v == nil then break end
        local mult = 1
        if (i % 2 == 0) then mult = -1 end
        -- Spin half a revolution
        v:rotate(6.28318531*percent*mult*0.5)
    end 
    -- Fade during the spin
    page.alpha = 1 - math.abs(percent)
end