--[[ ******************************************************************
Bouncy by KOP
******************************************************************* ]]
local a2 = {}
for i=1,48,1 do
        a2[i] = 0
end

local a3 = {}
for i=1,24,1 do
        a3[i] = 0
end
local a4 = {}
for i=1,24,1 do
        a4[i] = 0
end
return function(pg, of, sw, sh)

        pg:translate(of,0,0)

    local pc, cx, cy, ops = math.abs(of/pg.width), pg.width/2, pg.height/2, of/pg.width
        
        local fx=5*pc
        if fx>1 then fx=1 end
    for i, ic in subviews(pg) do
if pc<=0.01 then for i=1,48,1 do
        a2[i] = math.random(-100, 100)
end
end
if pc<=0.01 then for i=1,48,1 do
        a3[i] = math.random(-100, 100)
end
end
if pc<=0.01 then for i=1,48,1 do
        a4[i] = math.random(-100, 100)
end
end
local ba=0
if ops<0 then ba=24 end
                -- get icon center
                local icx, icy = (ic.x+ic.width/2), (ic.y+ic.height/2)
                -- get icon offset from page center
                local ox, oy = cx-icx, cy-icy
                
                -- get angle of icon position
                
                local g = (pc-0.01)*104/99
   if g<0 then g=0 end
if g>1 then g=1 end
                -- directions
                local dx, dy = 1,1
                if icx<cx then dx=-dx end
                if icy<cy then dy=-dy end
                if icy==cy then dy=0 end
                
                -- calc new x & y
                
                local nx = 15*g*a2[i+ba]+icx
                local ny = 15*g*a3[i+ba]+icy
                local nz = 15*g*a4[i+ba]
for i=1,12,1 do
if nx>pg.width then
nx=2*pg.width-nx end
if nx<0 then
nx=-nx
end
if ny>pg.height then
ny=2*pg.height-ny end
if ny<0 then
ny=-ny
end
if nz>.5*pg.width then
nz=pg.width-nz end
if nz<-.5*pg.width then
nz=-pg.width-nz
end
end
                
                -- move!
                ic:translate(nx-icx, ny-icy, nz)
                        ic.alpha = 1-g^2
                

    end
end

