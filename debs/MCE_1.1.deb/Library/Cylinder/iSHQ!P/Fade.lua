local M_PI = 3.14159265

local function fade(view, percent)
    local angle = percent*M_PI*2
    local x = percent

    if percent < 0 then x = -x end

    local i = 0
    while true do
        i = i + 1
        local v = view[i]
        if v == nil then break end
        v.alpha = 1 - x
    end
end

return function(page, offset, width, height)
    local percent = offset/width
    fade(page, percent)
end